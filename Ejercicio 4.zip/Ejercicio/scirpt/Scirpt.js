

var listaPalabras = [
  "ANIMAL",
  "ESCUELA",
  "PINGUINO",
  "ESTUDIANTE",
  "COMPUTADORA",
  "ZAPATO",
  "CIUDAD",
  "BOSQUE",
  "FUTBOL",
  "TALLER",
  "PLATAFORMA",
  "TECLADO",
  "CASA",
  "HERMANO"
]

